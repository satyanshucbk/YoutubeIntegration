import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ResultvideoPage } from './resultvideo';

@NgModule({
  declarations: [
    ResultvideoPage,
  ],
  imports: [
    IonicPageModule.forChild(ResultvideoPage),
  ],
})
export class ResultvideoPageModule {}
