import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HometabPage } from './hometab';

@NgModule({
  declarations: [
    HometabPage,
  ],
  imports: [
    IonicPageModule.forChild(HometabPage),
  ],
})
export class HometabPageModule {}
